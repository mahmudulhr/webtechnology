<!DOCTYPE html>
<html lang="en">

<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <meta http-equiv="X-UA-Compatible" content="ie=edge">
 <title>
  <?php echo TITLE ?>
 </title>
 <link rel="stylesheet" href="../css/bootstrap.min.css">
 <link rel="stylesheet" href="../css/all.min.css">
 <link rel="stylesheet" href="../css/custom.css">
</head>

<body>
 <nav class="navbar navbar-dark fixed-top bg-success p-0 shadow">
  <a class="navbar-brand col-sm-3 col-md-2 mr-2" href="dashboard.php">Golden Service</a>
 <a class="nav-link btn-warning" href="../logout.php">Logout</a>
 </nav>
 <div class="container-fluid mb-5" style="margin-top:40px;">
  <div class="row">
   <nav class="col-sm-3 col-md-2 bg-light sidebar py-5 d-print-none">
    <div class="sidebar-sticky">
     <ul class="nav flex-column">
      <li class="nav-item">
       <a class="nav-link bg-success text-white <?php if(PAGE == 'dashboard') { echo 'active'; } ?> " href="dashboard.php">
        Dashboard
       </a>
      </li>
      <li class="nav-item">
       <a class="nav-link bg-dark text-white<?php if(PAGE == 'request') { echo 'active'; } ?>" href="request.php">
        Requests
       </a>
      </li>   
      <li class="nav-item">
       <a class="nav-link bg-dark text-white<?php if(PAGE == 'requesters') { echo 'active'; } ?>" href="requester.php">
        Requester
       </a>
      </li>
     
      <li class="nav-item">
       <a class="nav-link bg-dark text-white <?php if(PAGE == 'changepass') { echo 'active'; } ?>" href="changepass.php">
        Change Password
       </a>
      </li>
     </ul>
    </div>
   </nav>