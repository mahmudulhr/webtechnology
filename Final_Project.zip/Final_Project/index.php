<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/all.min.css">
  <link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">
  <link rel="stylesheet" href="css/custom.css">
  <title>Final Project</title>
</head>

<body>
  <nav class="navbar navbar-expand-sm navbar-dark bg-success pl-5 fixed-top">
    <a href="index.php" class="navbar-brand">Golden Service</a>
    <div class="collapse navbar-collapse" id="myMenu">
      <ul class="navbar-nav pl-5 custom-nav text-white">
        <li class="nav-item"><a href="index.php" class="nav-link text-white">Home</a></li>
         <li class="nav-item"><a href="index.php" class="nav-link text-warning">About</a></li>
        <li class="nav-item"><a href="#Services" class="nav-link text-warning">Services</a></li>
         <li class="nav-item"><a href="#Contact" class="nav-link text-warning">Contact</a></li>
         &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <li class="nav-item "><a href="Requester/RequesterLogin.php" class="btn btn-dark mr-4 btn-center text-white">Login</a></li>
        <li class="nav-item "><a href="#registration" class="btn btn-warning mr-4 btn-center text-white">Sign Up</a></li>
      </ul>
    </div>
  </nav> 


  <header class="jumbotron back-image text-center" style="background-image: url(images/bb.jpg);">
    <div class="myclass mainHeading text-center py-5">
      <h1 class="text-uppercase text-success font-weight-bold text-center py-3">We Are The Best Online Service Provider</h1>
      <p class="text-success text-center ">We will Provide Best quility service for you Golden Services is Bnagladesh’s leading <br> chain of multi-brand online  service.
        wide array of services. We focus on <br> enhancing your uses experience by offering world-class
        Electronic</p>
        <a href="#Contact"class="btn btn-warning mr-4 btn-center text-white">Contact Us</a>
    </div>
  </header> 

  <div class="container ">
    <div class="jumbotron bg-light">
      <h3 class="text-center text-success">About Us</h3>
      <p class="text-success text-center">
        Golden Services is Bnagladesh’s leading chain of multi-brand online  service.
        wide array of services. We focus on enhancing your uses experience by offering world-class
        Electronic
        With well-equipped Electronic Appliances service centres and fully trained mechanics, we
        provide quality
        services with excellent packages that are designed to offer you great savings.

        Our state-of-art workshops are conveniently located in many cities across the country. Now you
        can book
        your service online by doing Registration.
      </p>

    </div>
  </div>
<div class="jumbotron bg-success py-5" id="Customer">
  <div class="container text-center border-bottom" id="Services">
    <h2 class="text-white py-5">Our Services</h2>
    <div class="row mt-4">
      <div class="col-sm-3 mb-3">
        <a href="#"><i class="fas fa-phone fa-4x text-warning"></i></a>
        <h4 class="mt-3 text-white">Electronic Gadget</h4>
      </div>
      <div class="col-sm-3 mb-3">
        <a href="#"><i class="fas fa-mobile fa-4x text-warning"></i></a>
        <h4 class="mt-3 text-white">Mobile Gadget</h4>
      </div>
      <div class="col-sm-3 mb-3">
        <a href="#"><i class="fas fa-laptop fa-4x text-warning"></i></a>
        <h4 class="mt-3 text-white">Laptop Gadget</h4>
      </div>
      <div class="col-sm-3 mb-3">
        <a href="#"><i class="fas fa-mobile fa-4x text-warning"></i></a>
        <h4 class="mt-3 text-white">Mobile servicing</h4>
      </div>
    </div>
  </div> 
</div>

 
 
  <div class="container py-5" id="Contact">
    <h2 class="text-left text-success mb-4">Contact US</h2> 
    <div class="row">

      <?php include('contactform.php'); ?>


    </div> 
  </div> 
<div class="jumbotron bg-success py-5" id="Customer">
<div class="container bg-success">
    <div class="jumbotron bg-success">
      <?php include('userRegistration.php') ?>
    </div>
 </div>
</div>

 <div class="jumbotron bg-white py-5" id="Customer">
    <div class="container">
      <h2 class="text-center text-success">Our Customers</h2>
      <div class="row mt-5">
        <div class="col-lg-4 col-sm-6">
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
              <img src="images/img3.jpeg" class="img-fluid" style="border-radius: 100px; height:100px; width:100px ">
              <h4 class="card-title">Nijhum</h4>
              <p class="card-text text-success">This is the best service provider company i have ever seen.</p>
            </div>
          </div>
        </div> 

        <div class="col-lg-4 col-sm-6">
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
              <img src="images/img1.jpg" class="img-fluid" style="border-radius: 100px; height:100px; width:100px">
              <h4 class="card-title">Mahmudul</h4>
              <p class="card-text text-success">This is the best service provider company i have ever seen.</p>
            </div>
          </div>
        </div>

        <div class="col-lg-4 col-sm-6">
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
              <img src="images/img2.jpeg" class="img-fluid" style="border-radius: 100px; height:100px; width:100px">
              <h4 class="card-title">Ifti</h4>
              <p class="card-text text-success">This is the best service provider company i have ever seen.</p>
            </div>
          </div>
        </div> 
      </div> 
    </div> 
  </div> 



  <footer class="container-fluid bg-success text-white " style="border-top: 0px solid #DC3545;">
    <div class="container">
      <div class="row">
        <div class="col-md-6 py-2">
          <small> All right reserved by golden service&copy; 2021.
          </small>
          <small class="ml-2"><a href="Admin/login.php">Admin Login</a></small>
        </div> 
        <div class="col-md-6 text-right py-2">
          <span class="pr-2">Follow Us: </span>
          <a href="#" target="_blank" class="pr-2 fi-color"><i class="fab fa-facebook-f text-white"></i></a>
          <a href="#" target="_blank" class="pr-2 fi-color"><i class="fab fa-twitter text-white"></i></a>
          <a href="#" target="_blank" class="pr-2 fi-color"><i class="fab fa-youtube text-white"></i></a>
        </div> 
      </div> 
    </div> 
  </footer> 

  <script src="js/jquery.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/all.min.js"></script>
</body>

</html>